export interface Character {
    quote:  string;
    author: string;
}

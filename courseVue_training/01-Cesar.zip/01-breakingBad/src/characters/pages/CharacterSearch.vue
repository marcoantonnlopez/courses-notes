<script setup lang="ts">

</script>

<template>
    <div>
        <h1>Character Search</h1>
    </div>
</template>

<style scoped>

</style>
<script setup lang="ts">

</script>

<template>
    <div>
        <h1>Character ID</h1>
    </div>
</template>

<style scoped>

</style>
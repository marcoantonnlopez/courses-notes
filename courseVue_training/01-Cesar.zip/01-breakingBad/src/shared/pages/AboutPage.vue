<script setup lang="ts">

</script>

<template>
    <div>
        <h1>AboutPage</h1>
    </div>
</template>

<style scoped>

</style>